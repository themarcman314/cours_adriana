#pragma once
#include "stm32l4xx.h"


void board_init();